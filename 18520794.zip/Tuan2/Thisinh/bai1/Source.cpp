#include "cStudent.h"
#include <iostream>
#include <string>
using namespace std;
int main()
{
	cStudent hocsinh;
	hocsinh.inputStudent();
	hocsinh.outputStudent();
	system("pause");
	return 0;
}