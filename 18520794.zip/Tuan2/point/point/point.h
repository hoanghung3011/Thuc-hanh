#pragma once
#include<iostream>
using namespace std;
class Point
{
private:
	float x, y;
public:
	Point();
	void nhap();
	void xuat();
	void tinhtien();
	~Point();
};