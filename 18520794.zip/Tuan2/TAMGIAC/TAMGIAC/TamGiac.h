#include "Diem.h"
class TamGiac
{
private:
	Diem a;
	Diem b;
	Diem c;
public:
	TamGiac();
	~TamGiac();
	void Nhap();
	void Xuat();
	void TinhTien(float, float);
	void Quay(int);
	void PhongTo(int);
	void ThuNho(int);
};

